package com.example.latex.presentation.screens.quiz

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.latex.data.ContentRepository
import com.example.latex.presentation.model.QuizData
import com.example.latex.presentation.screens.quiz.components.QuizAction
import com.example.latex.presentation.screens.quiz.components.QuizEvent
import com.example.latex.presentation.screens.quiz.components.QuizUiState
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import org.koin.core.component.KoinComponent
import kotlin.math.roundToInt

class QuizViewModel() : ViewModel(), KoinComponent {

    private val contentRepository = ContentRepository

    private val _state = mutableStateOf(QuizUiState())
    val state: State<QuizUiState> = _state

    private val _eventChannel = Channel<QuizAction>()
    val eventFlow: Flow<QuizAction> = _eventChannel.receiveAsFlow()


    private var quizList: ArrayList<QuizData> = ArrayList()
    private var questionsSize = 0


    init {
        getQuizData()
    }

    @RequiresApi(Build.VERSION_CODES.VANILLA_ICE_CREAM)
    fun onEvent(event: QuizEvent) {
        viewModelScope.launch {
            when (event) {
                is QuizEvent.Next -> {
                    if (quizList.size != 1) {
                        if ((state.value.selectedOption?.plus(1)
                                ?: 0) == state.value.quizData.answer
                        ) {
                            _eventChannel.send(QuizAction.Correct)

                        } else {
                            quizList.add(quizList.first())
                            _state.value = state.value.copy(attempts = state.value.attempts - 1)
                            _eventChannel.send(QuizAction.InCorrect)
                        }
                        quizList.removeFirst()

                        if (state.value.attempts != 0) {
                            _state.value = state.value.copy(
                                quizData = quizList.first(),
                                selectedOption = null,
                                progress = quizList.size.toFloat() / questionsSize
                            )
                        } else {
                            _eventChannel.send(QuizAction.NoAttemptsRemain)
                        }


                    } else {
                        if ((state.value.selectedOption?.plus(1)
                                ?: 0) == state.value.quizData.answer
                        ) {
                            _state.value = state.value.copy(
                                progress = 0f
                            )
                            _eventChannel.send(QuizAction.QuizCompleted)
                        } else {
                            _eventChannel.send(QuizAction.InCorrect)
                        }
                    }
                }

                is QuizEvent.SelectOption -> {
                    _state.value = state.value.copy(selectedOption = event.selectedOption)
                }

                is QuizEvent.UpdateProgress -> {



                }
            }
        }

    }


    private fun getQuizData() {
        quizList = contentRepository.getQuizData().toCollection(ArrayList())

        questionsSize = quizList.size

        _state.value = state.value.copy(
            quizData = quizList.first(),
            progress = quizList.size.toFloat() / questionsSize,
            attempts = (quizList.size * 0.3).roundToInt() + 1
        )

    }


}