package com.example.latex.presentation.screens.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.latex.R
import com.example.latex.ui.theme.CheckmarkIcon
import com.example.latex.ui.theme.CompassIcon
import com.example.latex.ui.theme.DocumentIcon
import com.example.latex.ui.theme.GlossaryIcon
import com.example.latex.ui.theme.InfoIcon
import com.example.latex.ui.theme.LaTEXTheme
import com.example.latex.ui.theme.PresentationIcon
import com.example.latex.ui.theme.SourceIcon
import com.example.latex.ui.theme.VideoIcon

@Composable
fun HomeScreen(
    onTheoriesClicked: () -> Unit = {},
    onVideosClicked: () -> Unit = {},
    onPracticalClicked: () -> Unit = {},
    onQuizzesClicked: () -> Unit = {},
    onDocumentsClicked: () -> Unit = {},
    onPresentationsClicked: () -> Unit = {},
    onGlossaryClicked: () -> Unit = {},
    onSourcesClicked: () -> Unit = {},
) {
    Scaffold(
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.latex),
                contentDescription = "Latex",
                modifier = Modifier
                    .size(300.dp)
                    .align(Alignment.BottomEnd)
                    .alpha(0.025f)
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.Top
            ) {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(R.drawable.latex_icon),
                        contentDescription = "logo",
                        modifier = Modifier.size(50.dp)
                    )
                    Spacer(Modifier.size(16.dp))
                    Text(
                        text = "Easy LaTex",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Medium
                    )
                }
                Spacer(modifier = Modifier.size(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ContentItemComponent(
                        icon = VideoIcon,
                        name = "Videolar",
                        modifier = Modifier.weight(1F),
                        onClick = {
                            onVideosClicked()
                        })
                    Spacer(Modifier.size(16.dp))
                    ContentItemComponent(
                        icon = DocumentIcon,
                        name = "Ma'ruzalar",
                        modifier = Modifier.weight(1F),
                        onClick = {
                            onTheoriesClicked()
                        })
                }
                Spacer(Modifier.size(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ContentItemComponent(
                        icon = CheckmarkIcon,
                        name = "Testlar",
                        modifier = Modifier.weight(1F),
                        onClick = {
                            onQuizzesClicked()
                        })
                    Spacer(Modifier.size(16.dp))
                    ContentItemComponent(
                        icon = CompassIcon,
                        modifier = Modifier.weight(1F),
                        name = "Amaliylar",
                        onClick = {
                            onPracticalClicked()
                        })
                }
                Spacer(Modifier.size(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ContentItemComponent(
                        icon = PresentationIcon,
                        name = "Taqdimotlar",
                        modifier = Modifier.weight(1F),
                        onClick = {
                            onPresentationsClicked()
                        })
                    Spacer(Modifier.size(16.dp))
                    ContentItemComponent(
                        icon = SourceIcon,
                        modifier = Modifier.weight(1F),
                        name = "Adabiyotlar",
                        onClick = {
                            onSourcesClicked()
                        })
                }
                Spacer(Modifier.size(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ContentItemComponent(
                        icon = InfoIcon,
                        name = "Hujjatlar",
                        modifier = Modifier.weight(1F),
                        onClick = {
                            onDocumentsClicked()
                        }
                    )
                    Spacer(Modifier.size(16.dp))
                    ContentItemComponent(
                        icon = GlossaryIcon,
                        modifier = Modifier.weight(1F),
                        name = "Glossary",
                        onClick = {
                            onGlossaryClicked()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ContentItemComponent(
    icon: ImageVector,
    name: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier = modifier
            .shadow(elevation = 2.dp, shape = RoundedCornerShape(8.dp))
            .background(
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Image(
            imageVector = icon,
            contentDescription = name,
            modifier = Modifier
                .size(80.dp),
            colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.primary)
        )

        Text(
            text = name,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )

    }
}


@Preview
@Composable
private fun HomePreview() {
    LaTEXTheme {
        Surface(color = MaterialTheme.colorScheme.surfaceContainerLowest) {
            HomeScreen()
        }
    }

}