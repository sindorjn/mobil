package com.example.latex.presentation.screens.documents

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.latex.data.UrlSourceRepository
import kotlinx.coroutines.launch

class DocumentsViewModel(
    savedStateHandle: SavedStateHandle,
) : ViewModel() {


    private val repository = UrlSourceRepository
    var state by mutableStateOf(DocumentsState())
        private set

    val itemsType = savedStateHandle.get<String>("itemType") ?: ""

    init {
        viewModelScope.launch {
            when (itemsType) {
                "document" -> {
                    state = state.copy(
                        title = "Hujjatlar",
                        itemNames = repository.docNames,
                        itemsTye = "document"
                    )
                }
                "presentation" -> {
                    state = state.copy(
                        title = "Taqdimotlar",
                        itemNames = repository.presentationNames,
                        itemsTye = "presentation"
                    )
                }
                "source" -> {
                    state = state.copy(
                        title = "Adabiyotlar",
                        itemNames = repository.sourceNames,
                        itemsTye = "source"
                    )
                }
            }
        }

    }

//    private fun loadDocuments() {
//        viewModelScope.launch {
//            state = state.copy(
//                title = "Hujjatlar",
//                itemNames = repository.docNames
//            )
//        }
//    }
//
//    private fun loadPresentations() {
//        viewModelScope.launch {
//            state = state.copy(
//                title = "Taqdimotlar",
//                itemNames = repository.presentationNames()
//            )
//        }
//    }


}