package com.example.latex.presentation.screens.quiz

import android.annotation.SuppressLint
import android.os.Build
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.latex.R
import com.example.latex.presentation.components.Headline
import com.example.latex.presentation.components.PrimaryButton
import com.example.latex.presentation.components.QuizCompletionDialog
import com.example.latex.presentation.screens.quiz.components.OptionsComponent
import com.example.latex.presentation.screens.quiz.components.QuestionComponent
import com.example.latex.presentation.screens.quiz.components.QuizAction
import com.example.latex.presentation.screens.quiz.components.QuizEvent
import org.koin.androidx.compose.koinViewModel

@RequiresApi(Build.VERSION_CODES.VANILLA_ICE_CREAM)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun QuizScreen(
    viewModel: QuizViewModel = koinViewModel(),
    navigateToModules: () -> Unit,
    onBack: () -> Unit,
) {

    val state = viewModel.state.value
    val context = LocalContext.current
    val showCompletedDialog = remember {
        mutableStateOf(false)
    }

    val showAttemptsFinishedDialog = remember {
        mutableStateOf(false)
    }
    var selectedImage by remember {
        mutableIntStateOf(R.drawable.successful_illustration)
    }

    LaunchedEffect(key1 = viewModel.eventFlow) {
        viewModel.eventFlow.collect {
            when (it) {
                is QuizAction.Correct -> {
                    Toast.makeText(
                        context,
                        listOf("Tog'ri", "Barakalla", "Ajoyib").random(),
                        Toast.LENGTH_SHORT
                    ).show()
                }

                is QuizAction.InCorrect -> {
                    Toast.makeText(context, "Noto'g'ri javob", Toast.LENGTH_SHORT).show()

                }

                is QuizAction.QuizCompleted -> {
                    Toast.makeText(context, "Test yakunlandi", Toast.LENGTH_SHORT).show()
                    showCompletedDialog.value = true

                }

                is QuizAction.NoAttemptsRemain -> {
                    showAttemptsFinishedDialog.value = true
                }

                is QuizAction.ShowErrorMessage -> {
                    Toast.makeText(context, it.message, Toast.LENGTH_SHORT).show()
                }

                is QuizAction.NavigateToModules -> {
                    navigateToModules()
                }

            }
        }
    }

    Scaffold(
        modifier = Modifier
            .background(MaterialTheme.colorScheme.surface)
            .statusBarsPadding(),
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(
                        horizontal = 16.dp,
                        vertical = 8.dp
                    )
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                if (state.loading) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Iltimos kutib turing ...",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.size(16.dp))
                        CircularProgressIndicator()

                    }
                } else {
                    Column {
                        Headline(
                            title = "Test",
                            progress = state.progress
                        ) {

                            onBack()
                        }

                        Spacer(modifier = Modifier.size(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            repeat(state.attempts) {
                                Image(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clickable {
                                            Toast
                                                .makeText(
                                                    context,
                                                    "Xato javob uchun urinishlar soni",
                                                    Toast.LENGTH_SHORT
                                                )
                                                .show()
                                        },
                                    painter = painterResource(id = R.drawable.heart),
                                    contentDescription = "heart"
                                )
                                Spacer(modifier = Modifier.size(8.dp))
                            }
                        }
                        Spacer(modifier = Modifier.size(16.dp))
                        QuestionComponent(
                            questionData = state.quizData.question,
                            onImageClick = {
                                selectedImage = it
                            }
                        )
                        Spacer(modifier = Modifier.size(24.dp))
                        OptionsComponent(
                            options = state.quizData.options,
                            onClickOption = {
                                viewModel.onEvent(QuizEvent.SelectOption(it))
                            },
                            selectedOption = state.selectedOption
                        )


                    }
                    PrimaryButton(
                        onClick = {
                            viewModel.onEvent(QuizEvent.Next)
                        },
                        text = "Keyingisi",
                        enabled = state.selectedOption != null
                    )

                }

            }
        }
    )

    QuizCompletionDialog(
        title = "Viktorina yakunlandi!",
        description = "Tabriklaymiz! Viktorinani muvaffaqiyatli yakunladingiz.",
        icon = R.drawable.successful_illustration,
        buttonColor = MaterialTheme.colorScheme.primary,
        showDialog = showCompletedDialog.value,
        buttonTitle = "Davom etish",
        onDismiss = {
            showCompletedDialog.value = false
        },
        onContinue = {
            showCompletedDialog.value = false
            onBack()
            viewModel.onEvent(QuizEvent.UpdateProgress)
        }
    )

    QuizCompletionDialog(
        title = "Urinishlar tugadi!",
        description = "Urinishlar soni tugadi. Darslarni qayta ko‘rib chiqib, testni qaytadan boshlang.",
        icon = R.drawable.ic_white_flag,
        buttonColor = MaterialTheme.colorScheme.error,
        showDialog = showAttemptsFinishedDialog.value,
        buttonTitle = "Tushunarli",
        onDismiss = {
            showAttemptsFinishedDialog.value = false
        },
        onContinue = {
            showAttemptsFinishedDialog.value = false
            onBack()
        }
    )


}