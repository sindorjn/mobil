package com.example.latex.presentation.screens.web

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.latex.data.UrlSourceRepository
import kotlinx.coroutines.launch

class WebViewModel(
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    var state by mutableStateOf(WebState())
        private set

    val urlIndex = savedStateHandle.get<Int>("urlIndex") ?: 0
    val practiceType = savedStateHandle.get<String>("practiceType") ?: ""

    init {
        viewModelScope.launch {
            when (practiceType) {
                "lab" -> {
                    state = state.copy(
                        url = UrlSourceRepository.labs[urlIndex],
                        title = "Laboratoriya"
                    )
                }

                "task" -> {
                    state = state.copy(
                        url = UrlSourceRepository.tasks[urlIndex],
                        title = "Mustaqil ishi"
                    )
                }

                "document" -> {
                    state = state.copy(
                        url = UrlSourceRepository.docs[urlIndex],
                        title = "Hujjat"
                    )
                }

                "presentation" -> {
                    state = state.copy(
                        url = UrlSourceRepository.presentations[urlIndex],
                        title = "Taqdimot"
                    )
                }

                "source" -> {
                    state = state.copy(
                        url = UrlSourceRepository.sources[urlIndex],
                        title = "Adabiyotlar"
                    )
                }

                "glossary" -> {
                    state = state.copy(
                        url = UrlSourceRepository.glossary,
                        title = "Glossary"
                    )
                }
            }

        }
    }


}