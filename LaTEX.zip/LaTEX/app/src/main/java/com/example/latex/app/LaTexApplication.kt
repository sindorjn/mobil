package com.example.latex.app

import android.app.Application
import com.example.latex.di.appModule
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin

class LaTexApplication: Application() {

    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidLogger()
            androidContext(this@LaTexApplication)
            modules(
                appModule,
            )
        }

    }
}