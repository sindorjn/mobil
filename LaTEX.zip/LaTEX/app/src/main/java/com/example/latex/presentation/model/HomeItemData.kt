package com.example.latex.presentation.model

import androidx.compose.ui.graphics.vector.ImageVector

data class HomeItemData(
    val icon: ImageVector,
    val name: String
)
