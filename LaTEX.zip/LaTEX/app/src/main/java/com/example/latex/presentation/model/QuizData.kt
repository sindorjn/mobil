package com.example.latex.presentation.model

data class QuizData(
    val question:QuestionData,
    val options: List<String>,
    val answer: Int
)
