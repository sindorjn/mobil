package com.example.latex.presentation.screens.videos

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import com.example.latex.presentation.components.SearchBar
import com.example.latex.presentation.components.YouTubeVideoItem
import org.koin.androidx.compose.koinViewModel


@Composable

fun VideosScreenRoot(
    viewModel: VideosViewModel = koinViewModel(),
    onBack: () -> Unit,
) {

    VideosScreen(
        state = viewModel.state,
        onAction = { action ->
            when (action) {
                is VideosAction.OnSearch -> {
                    viewModel.onAction(action)
                }

                VideosAction.OnBack -> {
                    onBack()
                }
            }
        }
    )

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VideosScreen(
    state: VideosState,
    onAction: (VideosAction) -> Unit,
) {
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior()
    val context = LocalContext.current

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                modifier = Modifier,
                scrollBehavior = scrollBehavior,
                title = {
                    Spacer(Modifier.size(16.dp))
                    Text(
                        text = "Video darsliklar",
                        modifier = Modifier,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                },
                navigationIcon = {
                    Spacer(Modifier.size(16.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable {
                                onAction.invoke(VideosAction.OnBack)
                            }
                            .padding(12.dp)
                    )
                }
            )
        },
        contentColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {

            SearchBar(
                modifier = Modifier.fillMaxWidth(),
                hint = "Qidirish...",
                onSearch = {
                    onAction(VideosAction.OnSearch(it))
                }
            )
            Spacer(Modifier.padding(8.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                items(state.videos) { video ->
                    YouTubeVideoItem(video = video) {
                        val intent = Intent(Intent.ACTION_VIEW, video.videoUrl.toUri())
                        context.startActivity(intent)
                    }
                }
            }
        }
    }


}
