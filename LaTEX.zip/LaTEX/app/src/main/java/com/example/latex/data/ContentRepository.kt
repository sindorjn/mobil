package com.example.latex.data

import com.example.latex.presentation.model.QuestionData
import com.example.latex.presentation.model.QuizData

object ContentRepository {
    fun getQuizData(): List<QuizData> =
        listOf(
            QuizData(
                question = QuestionData.Text(
                    "Tex va Latex matn muharriri kim tomonidan ishlab chiqilgan?"
                ),
                options = listOf(
                    "D.E.Knut", // Incorrect
                    "Lesli Lamportan", // Correct (LaTeX creator)
                    "Bill Geyst", // Incorrect
                    "Jozayya Uillard Gibbs" // Incorrect
                ),
                answer = 2 // Lesli Lamportan is correct
            ),
            QuizData(
                question = QuestionData.Text(
                    "Tex va Latex matn muharriri qaysi universitetda ishlab chiqilgan?"
                ),
                options = listOf(
                    "Stanford Universitetida", // Correct (TeX was developed at Stanford by Donald Knuth)
                    "Kembridje", // Incorrect
                    "Oxford", // Incorrect
                    "Lamonosov" // Incorrect
                ),
                answer = 1// Stanford Universitetida is correct
            ),
            QuizData(
                question = QuestionData.Text(
                    "Latex hujjat turlari asosan nechtaga bo'linadi?"
                ),
                options = listOf(
                    "4", // Correct (Article, Book, Letter, Report)
                    "3", // Incorrect
                    "5", // Incorrect
                    "6" // Incorrect
                ),
                answer = 1 // 4 is correct
            ),
            QuizData(
                question = QuestionData.Text(
                    "Latex hujjat turlari asosan qaysilar hisoblanadi?"
                ),
                options = listOf(
                    "Maqola, Ma'ruza, Kitob, Xat", // Correct (Article, Report, Book, Letter)
                    "Maqola, kitob", // Incorrect
                    "Kitob, xat, maqola", // Incorrect
                    "Ma'ruza, amaliyot, laboratoriya" // Incorrect
                ),
                answer = 1 // "Maqola, Ma'ruza, Kitob, Xat" is correct
            ),
            QuizData(
                question = QuestionData.Text(
                    "Latex hujjatining umumiy tarkibi necha qismdan iborat?"
                ),
                options = listOf(
                    "2", // Incorrect
                    "3", // Correct (Preamble, Document Body, Additional Sections)
                    "4", // Incorrect
                    "5" // Incorrect
                ),
                answer = 2 // 3 is correct
            ),
            QuizData(
                question = QuestionData.Text(
                    "Latex hujjatining umumiy tarkibi qaysilar?"
                ),
                options = listOf(
                    "Bosh qism, asosiy qism", // Incorrect
                    "Bosh qism, asosiy qism, qo'shimcha qism", // Correct
                    "Asosiy qism, qo'shimcha qism", // Incorrect
                    "Qo'shimcha qism, bosh qism" // Incorrect
                ),
                answer = 2 // "Bosh qism, asosiy qism, qo'shimcha qism" is correct
            ),
            QuizData(
                question = QuestionData.Text(
                    "Latex hujjatining Bosh qismi"
                ),
                options = listOf(
                    "Priambula", // Correct (Preamble in English)
                    "Document", // Incorrect
                    "Article", // Incorrect
                    "math" // Incorrect
                ),
                answer = 1 // "Priambula" is correct
            ),
            QuizData(
                question = QuestionData.Text(
                    "Latex buyruqlari qaysi belgi orqali boshlandi?"
                ),
                options = listOf(
                    "\\", // Correct (Backslash starts LaTeX commands)
                    "&", // Incorrect
                    "\\%", // Incorrect
                    "\\\\\\\\" // Incorrect
                ),
                answer = 1 // "\\" is correct
            ),
            QuizData(
                question = QuestionData.Text(
                    "Latex buyruqlari necha xil bo'ladi?"
                ),
                options = listOf(
                    "2", // Correct (Command words and command symbols)
                    "3", // Incorrect
                    "4", // Incorrect
                    "5" // Incorrect
                ),
                answer = 1 // 2 is correct
            ),
            QuizData(
                question = QuestionData.Text(
                    "Latex buyruqlari necha xil bo'ladi?"
                ),
                options = listOf(
                    "buyruq so'zlar va buyruq belgilar", // Correct
                    "Buyruq so'zlar va kirish so'z", // Incorrect
                    "Buyruq belgilar va tugashish", // Incorrect
                    "Buyruq so'zlarm buyruq belgilar, boshlash va tugatish" // Incorrect
                ),
                answer = 1 // "buyruq so'zlar va buyruq belgilar" is correct
            )
        )
}
