package com.example.latex.presentation.screens.web

import androidx.compose.ui.res.stringResource

data class WebState(
    val url: String = "",
    val title: String = "LaTex",
)
