package com.example.latex.data

import com.example.latex.data.model.YouTubeVideo




object LocalRepository {
    val sampleVideos = listOf(
        YouTubeVideo(title = "Latex uchun kerakli dasturlarni o'rnatish", thumbnailUrl = "https://img.youtube.com/vi/S6_pEz-uwHQ/maxresdefault.jpg", videoUrl = "https://www.youtube.com/watch?v=S6_pEz-uwHQ"),
        YouTubeVideo(title = "LaTex [1-dars]: LaTex dasturini ishga tushirish", thumbnailUrl = "https://img.youtube.com/vi/yzcPOAqSgv8/maxresdefault.jpg", videoUrl = "https://www.youtube.com/watch?v=yzcPOAqSgv8"),
        YouTubeVideo(title = "LaTex [2-dars]: LaTex da matnni chap, o'ng va markazga tekislash", thumbnailUrl = "https://img.youtube.com/vi/do6dUL6AOOA/maxresdefault.jpg", videoUrl = "https://www.youtube.com/watch?v=do6dUL6AOOA"),
        YouTubeVideo(title = "LaTex [3-dars]: LaTex dasturida matn shrifti o'lchami va formatini belgilash", thumbnailUrl = "https://img.youtube.com/vi/R3-yteRo8-4/maxresdefault.jpg", videoUrl = "https://www.youtube.com/watch?v=R3-yteRo8-4"),
        YouTubeVideo(title = "LaTex [4-dars]: LaTex dasturida matematik formula va simvollarni yozish", thumbnailUrl = "https://img.youtube.com/vi/Np_s37SkUXk/maxresdefault.jpg", videoUrl = "https://www.youtube.com/watch?v=Np_s37SkUXk"),
        YouTubeVideo(title = "LaTex [5-dars]: LaTex da matematik matnlarni yozish", thumbnailUrl = "https://img.youtube.com/vi/MgXrHej5zvA/maxresdefault.jpg", videoUrl = "https://www.youtube.com/watch?v=MgXrHej5zvA"),
        YouTubeVideo(title = "LaTex [6-dars]: LaTex dasturida matematik formula va simvollarni yozishda davom", thumbnailUrl = "https://img.youtube.com/vi/VPMBWTYw7bw/maxresdefault.jpg", videoUrl = "https://www.youtube.com/watch?v=VPMBWTYw7bw"),
        YouTubeVideo(title = "LaTex [7-dars]: LaTex dasturida matematik ifodalarni yozishda davom etamiz", thumbnailUrl = "https://img.youtube.com/vi/jty4nWGfgUw/maxresdefault.jpg", videoUrl = "https://www.youtube.com/watch?v=jty4nWGfgUw"),
        YouTubeVideo(title = "LaTex [9-dars]: LaTex dasturida matnlarda kolonka va ro'yxat shakllantirish", thumbnailUrl = "https://img.youtube.com/vi/g12Lc_3eFZI/maxresdefault.jpg", videoUrl = "https://www.youtube.com/watch?v=g12Lc_3eFZI"),
        YouTubeVideo(title = "LaTex [10-dars]: LaTex dasturida matnga rasm joylash", thumbnailUrl = "https://img.youtube.com/vi/udyHlGdWhKE/maxresdefault.jpg", videoUrl = "https://www.youtube.com/watch?v=udyHlGdWhKE"),
    )



}