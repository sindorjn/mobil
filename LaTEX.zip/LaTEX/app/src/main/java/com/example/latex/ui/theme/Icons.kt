package com.example.latex.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import com.example.latex.R

val VideoIcon: ImageVector
    @Composable
    get() = ImageVector.vectorResource(id = R.drawable.youtube)

val DocumentIcon: ImageVector
    @Composable
    get() = ImageVector.vectorResource(id = R.drawable.file_text)

val InfoIcon: ImageVector
    @Composable
    get() = ImageVector.vectorResource(id = R.drawable.info)

val CheckmarkIcon: ImageVector
    @Composable
    get() = ImageVector.vectorResource(id = R.drawable.check_square)

val CompassIcon: ImageVector
    @Composable
    get() = ImageVector.vectorResource(id = R.drawable.compass)

val PresentationIcon: ImageVector
    @Composable
    get() = ImageVector.vectorResource(id = R.drawable.presentations)

val GlossaryIcon: ImageVector
    @Composable
    get() = ImageVector.vectorResource(id = R.drawable.glossary)

val SourceIcon: ImageVector
    @Composable
    get() = ImageVector.vectorResource(id = R.drawable.source)
