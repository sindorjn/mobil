package com.example.latex.di

import com.example.latex.presentation.screens.documents.DocumentsViewModel
import com.example.latex.presentation.screens.modules.ModulesViewModule
import com.example.latex.presentation.screens.quiz.QuizViewModel
import com.example.latex.presentation.screens.theories.TheoryViewModel
import com.example.latex.presentation.screens.videos.VideosViewModel
import com.example.latex.presentation.screens.web.WebViewModel
import org.koin.androidx.viewmodel.dsl.viewModelOf
import org.koin.dsl.module

val appModule = module {
    viewModelOf(::VideosViewModel)
    viewModelOf(::TheoryViewModel)
    viewModelOf(::ModulesViewModule)
    viewModelOf(::QuizViewModel)
    viewModelOf(::WebViewModel)
    viewModelOf(::DocumentsViewModel)
}