package com.example.latex.presentation.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun Headline(
    title: String,
    modifier: Modifier = Modifier,
    progress: Float? = null,
    onBack: () -> Unit
) {

    Box(
        modifier = modifier
            .fillMaxWidth()

    ) {

        Image(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "",
            modifier = Modifier
                .size(38.dp)
                .background(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.2f))
                .clip(shape = RoundedCornerShape(20.dp))
                .clickable {
                    onBack()
                }
                .padding(8.dp)
                .align(Alignment.CenterStart),
            colorFilter = ColorFilter.tint(color = MaterialTheme.colorScheme.onSurface)
        )

        Text(
            text = title,
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(0.7f),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
        if (progress != null) {
            CircularProgressIndicator(
                progress = {
                    progress
                },
                trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                color = MaterialTheme.colorScheme.primary,
                strokeWidth = 6.dp,
                modifier = Modifier.align(Alignment.CenterEnd)
            )

        }

    }

}