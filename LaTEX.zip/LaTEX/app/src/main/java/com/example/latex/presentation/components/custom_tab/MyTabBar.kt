package com.example.latex.presentation.components.custom_tab


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun MyTabBar(
    indicatorOffset: Dp,
    indicatorColor: Color,
    indicatorWidthFraction:Float
) {


    Box(
        modifier = Modifier
            .padding(vertical = 4.dp)
            .fillMaxHeight()
            .fillMaxWidth(indicatorWidthFraction)
            .offset(x = indicatorOffset)
            .clip(shape = RoundedCornerShape(8.dp))
            .background(color = indicatorColor)
            .height(intrinsicSize = IntrinsicSize.Min)

    )
}