package com.example.latex.presentation.screens.practice

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

//class PracticeViewModule : ViewModel() {
//
//    var state by mutableStateOf(PracticeState())
//
//    var practices = listOf<String>()
//
//    init {
//        loadModules()
//    }
//
//    private fun loadModules() {
//        state = state.copy(
//            modules =
//        )
//    }
//
//
//}