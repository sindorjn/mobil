package com.example.latex.data

import com.example.latex.R
import com.example.latex.presentation.screens.theories.TheoryItemData

object TheoryRepository {

    fun getModuleNames(): List<String> {
        return listOf(
            "LATEX-ga kirish",
            "Hujjat strukturasi",
            "Hujjat stili",
            "Hоshiyasi maydоni bilan ishlash",
            "Hujjatlarni fоrmatlash",
            "Jadvallar bilan ishlash",
            "Hujjatda obyektlar bilan ishlash",
            "Tasvirlar bilan ishlash",
            "LATEX ning grafik imkоniyatlari",
            "Matematik formulalar bilan ishlash",
            "Murakkab formulalar",
            "Matematik formulalar bilan ishlash imkoniyatlari",
            "Taqdimot yaratish",
            "Murakkab strukturali hujjat yaratish",
            "Dasturlash asoslari"
        )
    }


    fun getTheories(lessonIndex: Int): List<TheoryItemData> {
        return allTheories[lessonIndex]
    }


    val firstLesson = listOf(
        TheoryItemData.Title(R.string.latex1_title1),
        TheoryItemData.Description(R.string.latex1_description1),

        TheoryItemData.Title(R.string.latex1_title2),
        TheoryItemData.Description(R.string.latex1_description2),

        TheoryItemData.Title(R.string.latex1_title3),
        TheoryItemData.Description(R.string.latex1_description3),
        TheoryItemData.Image(R.drawable.ltx1_1),
        TheoryItemData.Title(R.string.latex1_title4),
        TheoryItemData.Description(R.string.latex1_description4),

        TheoryItemData.Title(R.string.latex1_title5),
        TheoryItemData.Description(R.string.latex1_description5),

        TheoryItemData.Title(R.string.latex1_title6),
        TheoryItemData.Description(R.string.latex1_description6)
    )
    val secondLesson = listOf(
        TheoryItemData.Title(R.string.latex2_title1),
        TheoryItemData.Description(R.string.latex2_description1),

        TheoryItemData.Title(R.string.latex2_title2),
        TheoryItemData.Description(R.string.latex2_description2),

        TheoryItemData.Title(R.string.latex2_title3),
        TheoryItemData.Description(R.string.latex2_description3),

        TheoryItemData.Title(R.string.latex2_title4),
        TheoryItemData.Description(R.string.latex2_description4),

        TheoryItemData.Title(R.string.latex2_title5),
        TheoryItemData.Description(R.string.latex2_description5),

        TheoryItemData.Title(R.string.latex2_title6),
        TheoryItemData.Description(R.string.latex2_description6),

        TheoryItemData.Title(R.string.latex2_title7),
        TheoryItemData.Description(R.string.latex2_description7)
    )
    val thirdLesson = listOf(
        TheoryItemData.Title(R.string.latex3_title1),
        TheoryItemData.Description(R.string.latex3_description1),
        TheoryItemData.Title(R.string.latex3_title2),
        TheoryItemData.Description(R.string.latex3_description2),
        TheoryItemData.Title(R.string.latex3_title3),
        TheoryItemData.Description(R.string.latex3_description3),
        TheoryItemData.Title(R.string.latex3_title4),
        TheoryItemData.Description(R.string.latex3_description4),
        TheoryItemData.Title(R.string.latex3_title5),
        TheoryItemData.Description(R.string.latex3_description5)
    )
    val fourthLesson = listOf(
        TheoryItemData.Title(R.string.latex4_title1),
        TheoryItemData.Description(R.string.latex4_description1),

        TheoryItemData.Title(R.string.latex4_title2),
        TheoryItemData.Description(R.string.latex4_description2),

        TheoryItemData.Title(R.string.latex4_title3),
        TheoryItemData.Description(R.string.latex4_description3),

        TheoryItemData.Title(R.string.latex4_title4),
        TheoryItemData.Description(R.string.latex4_description4),

        TheoryItemData.Title(R.string.latex4_title5),
        TheoryItemData.Description(R.string.latex4_description5),

        TheoryItemData.Title(R.string.latex4_title6),
        TheoryItemData.Description(R.string.latex4_description6),

        TheoryItemData.Title(R.string.latex4_title7),
        TheoryItemData.Description(R.string.latex4_description7),

        TheoryItemData.Title(R.string.latex4_title8),
        TheoryItemData.Description(R.string.latex4_description8),

        TheoryItemData.Title(R.string.latex4_title9),
        TheoryItemData.Description(R.string.latex4_description9),

        TheoryItemData.Title(R.string.latex4_title10),
        TheoryItemData.Description(R.string.latex4_description10)
    )

    val fifthLesson = listOf(
        TheoryItemData.Title(R.string.latex5_title1),
        TheoryItemData.Description(R.string.latex5_description1),
        TheoryItemData.Title(R.string.latex5_title2),
        TheoryItemData.Description(R.string.latex5_description2),
        TheoryItemData.Title(R.string.latex5_title3),
        TheoryItemData.Description(R.string.latex5_description3),
        TheoryItemData.Title(R.string.latex5_title4),
        TheoryItemData.Description(R.string.latex5_description4)
    )
    val sixthLesson = listOf(
        TheoryItemData.Title(R.string.latex6_title1),
        TheoryItemData.Description(R.string.latex6_description1),

        TheoryItemData.Title(R.string.latex6_title2),
        TheoryItemData.Description(R.string.latex6_description2),

        TheoryItemData.Title(R.string.latex6_title3),
        TheoryItemData.Description(R.string.latex6_description3),

        TheoryItemData.Title(R.string.latex6_title4),
        TheoryItemData.Description(R.string.latex6_description4),

        TheoryItemData.Title(R.string.latex6_title5),
        TheoryItemData.Description(R.string.latex6_description5),

        TheoryItemData.Title(R.string.latex6_title6),
        TheoryItemData.Description(R.string.latex6_description6),

        TheoryItemData.Title(R.string.latex6_title7),
        TheoryItemData.Description(R.string.latex6_description7),

        TheoryItemData.Title(R.string.latex6_title8),
        TheoryItemData.Description(R.string.latex6_description8),

        TheoryItemData.Title(R.string.latex6_title9),
        TheoryItemData.Description(R.string.latex6_description9)
    )

    val seventhLesson = listOf(
        TheoryItemData.Title(R.string.latex7_title1),
        TheoryItemData.Description(R.string.latex7_description1),
        TheoryItemData.Title(R.string.latex7_title2),
        TheoryItemData.Description(R.string.latex7_description2),
        TheoryItemData.Title(R.string.latex7_title3),
        TheoryItemData.Description(R.string.latex7_description3),
        TheoryItemData.Title(R.string.latex7_title4),
        TheoryItemData.Description(R.string.latex7_description4),
        TheoryItemData.Title(R.string.latex7_title5),
        TheoryItemData.Description(R.string.latex7_description5),
        TheoryItemData.Title(R.string.latex7_title6),
        TheoryItemData.Description(R.string.latex7_description6),
        TheoryItemData.Title(R.string.latex7_title7),
        TheoryItemData.Description(R.string.latex7_description7)
    )

    val eighthLesson = listOf(
        TheoryItemData.Title(R.string.latex8_title1),
        TheoryItemData.Description(R.string.latex8_description1),
        TheoryItemData.Title(R.string.latex8_title2),
        TheoryItemData.Description(R.string.latex8_description2),
        TheoryItemData.Title(R.string.latex8_title3),
        TheoryItemData.Description(R.string.latex8_description3),
        TheoryItemData.Title(R.string.latex8_title4),
        TheoryItemData.Description(R.string.latex8_description4),
        TheoryItemData.Title(R.string.latex8_title5),
        TheoryItemData.Description(R.string.latex8_description5)
    )
    val ninthLesson = listOf(
        TheoryItemData.Title(R.string.latex9_title1),
        TheoryItemData.Description(R.string.latex9_description1),
        TheoryItemData.Title(R.string.latex9_title2),
        TheoryItemData.Description(R.string.latex9_description2),
        TheoryItemData.Title(R.string.latex9_title3),
        TheoryItemData.Description(R.string.latex9_description3),
        TheoryItemData.Title(R.string.latex9_title4),
        TheoryItemData.Description(R.string.latex9_description4),
        TheoryItemData.Title(R.string.latex9_title5),
        TheoryItemData.Description(R.string.latex9_description5)
    )

    val tenthLesson = listOf(
        TheoryItemData.Title(R.string.latex10_title1),
        TheoryItemData.Description(R.string.latex10_description1),
        TheoryItemData.Title(R.string.latex10_title2),
        TheoryItemData.Description(R.string.latex10_description2),
        TheoryItemData.Title(R.string.latex10_title3),
        TheoryItemData.Description(R.string.latex10_description3),
        TheoryItemData.Title(R.string.latex10_title4),
        TheoryItemData.Description(R.string.latex10_description4),
        TheoryItemData.Title(R.string.latex10_title5),
        TheoryItemData.Description(R.string.latex10_description5),
        TheoryItemData.Title(R.string.latex10_title6),
        TheoryItemData.Description(R.string.latex10_description6)
    )
    val eleventhLesson = listOf(
        TheoryItemData.Title(R.string.latex11_title1),
        TheoryItemData.Description(R.string.latex11_description1),
        TheoryItemData.Title(R.string.latex11_title2),
        TheoryItemData.Description(R.string.latex11_description2),
        TheoryItemData.Title(R.string.latex11_title3),
        TheoryItemData.Description(R.string.latex11_description3),
        TheoryItemData.Title(R.string.latex11_title4),
        TheoryItemData.Description(R.string.latex11_description4),
        TheoryItemData.Title(R.string.latex11_title5),
        TheoryItemData.Description(R.string.latex11_description5),
        TheoryItemData.Title(R.string.latex11_title6),
        TheoryItemData.Description(R.string.latex11_description6)
    )

    val twelfthLesson = listOf(
        TheoryItemData.Title(R.string.latex12_title1),
        TheoryItemData.Description(R.string.latex12_description1),
        TheoryItemData.Title(R.string.latex12_title2),
        TheoryItemData.Description(R.string.latex12_description2),
        TheoryItemData.Title(R.string.latex12_title3),
        TheoryItemData.Description(R.string.latex12_description3),
        TheoryItemData.Title(R.string.latex12_title4),
        TheoryItemData.Description(R.string.latex12_description4)
    )

    val thirteenthLesson = listOf(
        TheoryItemData.Title(R.string.latex13_title1),
        TheoryItemData.Description(R.string.latex13_description1),
        TheoryItemData.Title(R.string.latex13_title2),
        TheoryItemData.Description(R.string.latex13_description2),
        TheoryItemData.Title(R.string.latex13_title3),
        TheoryItemData.Description(R.string.latex13_description3),
        TheoryItemData.Title(R.string.latex13_title4),
        TheoryItemData.Description(R.string.latex13_description4)
    )
    val fourteenthLesson = listOf(
        TheoryItemData.Title(R.string.latex14_title1),
        TheoryItemData.Description(R.string.latex14_description1),
        TheoryItemData.Title(R.string.latex14_title2),
        TheoryItemData.Description(R.string.latex14_description2),
        TheoryItemData.Title(R.string.latex14_title3),
        TheoryItemData.Description(R.string.latex14_description3)
    )
    val fifteenthLesson = listOf(
        TheoryItemData.Title(R.string.latex15_title1),
        TheoryItemData.Description(R.string.latex15_description1),
        TheoryItemData.Title(R.string.latex15_title2),
        TheoryItemData.Description(R.string.latex15_description2),
        TheoryItemData.Title(R.string.latex15_title3),
        TheoryItemData.Description(R.string.latex15_description3),
        TheoryItemData.Title(R.string.latex15_title4),
        TheoryItemData.Description(R.string.latex15_description4),
        TheoryItemData.Title(R.string.latex15_title5),
        TheoryItemData.Description(R.string.latex15_description5),
        TheoryItemData.Title(R.string.latex15_title6),
        TheoryItemData.Description(R.string.latex15_description6)
    )


    val allTheories = listOf(
        firstLesson,
        secondLesson,
        thirdLesson,
        fourthLesson,
        fifthLesson,
        sixthLesson,
        seventhLesson,
        eighthLesson,
        ninthLesson,
        tenthLesson,
        eleventhLesson,
        twelfthLesson,
        thirteenthLesson,
        fourteenthLesson,
        fifteenthLesson
    )
}