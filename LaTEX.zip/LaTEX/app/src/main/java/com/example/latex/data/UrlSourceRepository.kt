package com.example.latex.data

object UrlSourceRepository {

    val labs: List<String> = listOf(
        "https://drive.google.com/file/d/1wgJFEt5_anacYhGBM6PZxsGITl6ZytQY/view?usp=sharing",
        "https://drive.google.com/file/d/1dwJdCLNOCVNxqchPoUM3pkoXJMaCotmA/view?usp=sharing",
        "https://drive.google.com/file/d/1IZZZRpsJTkD7wBpmf3z8J32jnPhyU2sP/view?usp=sharing",
        "https://drive.google.com/file/d/1qFywZDu69LNuuIc9c0RiYTALMIU1lQq4/view?usp=sharing",
        "https://drive.google.com/file/d/1GAompE-wjM05P6Ik9S4_2Y3U_zfCN1jh/view?usp=sharing",
        "https://drive.google.com/file/d/1EilKr2ZU7GozZ9eEhdNUNQPl7DeZk2II/view?usp=sharing",
        "https://drive.google.com/file/d/1-waxDpgU_9kJIfE-lKON0v9vx56YP6Tl/view?usp=sharing",
        "https://drive.google.com/file/d/15HejdU--GYojKeLqqYxfuex3r5Fd7L-f/view?usp=sharing",
        "https://drive.google.com/file/d/17vllk3dMVoIexjUUlE3ebII8zV_NbVjU/view?usp=sharing",
    )

    val tasks: List<String> = listOf(
        "https://drive.google.com/file/d/1Po_JCy-9rZeilIDFmOYIZ__11tCtw0Rn/view?usp=sharing",
        "https://drive.google.com/file/d/10KDyQbzBX54ilWCmmJmkAEINZ8XPRrOc/view?usp=sharing",
        "https://drive.google.com/file/d/1oqv1zMegsctu4ONxAnogU4TxQKG13HpV/view?usp=sharing",
        "https://drive.google.com/file/d/1w5pp8YRzxgLsBFQSrw3Px-qILSTbgxO_/view?usp=sharing"
    )


    val docs: List<String> = listOf(
        "https://drive.google.com/file/d/1nNj1JaOz6QsdU0fwkCcLPCPQAFSl5br-/view?usp=sharing",
        "https://drive.google.com/file/d/1VQ4HuJMb2AoUx-_JaLMIu_W1_CkTYD8N/view?usp=sharing",
        "https://drive.google.com/file/d/1cYQ5qS3xjs1ohmDAOxl3IPLhSb3S8Mn0/view?usp=sharing"
    )

    val presentations = listOf(
        "https://docs.google.com/presentation/d/1hrt8TD-x5-Ona_TPnH3rGDqZjUV-CDF5/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1c3t4GAgQzeRV8NBcSFwEyrDGz8or5xjv/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/14AHR5yXbciWqh50BEjqUV1Yv7_BlWLy7/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1pReHSqSMQxDSB4uIvUDnbAxwQEDn_2on/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1LNHYRFA_CGyEbAUYUe0WcihdZ9CPC7dy/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1kxP-vFPZPw5lh_0s7T9b98TAsIqP6UA2/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1WDyPTAigqIM8ii7uvqaJA0hMVMcyn3Ju/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1zyBxFI-PIdBQygcyEVqlkB9LNtybcO7c/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/15hN0xOq5175L2gUnjG1SJrwxyNt8nwQw/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1NQTMBz-no4wLpOtZurj84EFbb9ac59Zw/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1jL5lRd3D2x2x4gDTaiAXVHtqMl8A11p-/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1NdNbpYdp_WyNe4_uG40hF34ps-fd7ofX/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1vRqGobDMNdbpxejkbGNwQ7KQx77sx0GD/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1uzn0Qchy-afXLbZaG0s-4kpcTToJPxCt/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
        "https://docs.google.com/presentation/d/1goCIV6TQrpz19URPwhvtK5s2950_4qky/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
    )

    val sources = listOf(
        "https://drive.google.com/file/d/1Y9i15v_CKH7dajXuNwTYVOhg_Tahqj6J/view?usp=sharing",
        "https://drive.google.com/file/d/138Utwe5mZyAuSR3IgKgBITmIBYasH7nG/view?usp=sharing",
        "https://drive.google.com/file/d/1z-f4g5trmnoLVlsUJBkqsdz1C75jFjlA/view?usp=sharing",
        "https://drive.google.com/file/d/1ATAAGLdNHpxHLGSa8zlNk5VFymqFcA-b/view?usp=sharing",
        "https://drive.google.com/file/d/1DtgnVUzk51BxbTS_R_I1xaurqMlCXVpX/view?usp=sharing",
        "https://docs.google.com/document/d/1UkX1F0L417A6nl5ZqT2WaWP5Zn_ZaYvN/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true",
    )

    val glossary = "https://docs.google.com/document/d/1uprQmP5YbL7DyjtY3tJn9UkDmyphPQTp/edit?usp=sharing&ouid=114160193321406958684&rtpof=true&sd=true"

    val sourceNames = listOf(
        "1-Столяров А",
        "2-Львовский глав",
        "3-Е.М.Балдин",
        "4-N.S.Belyakov, V.E.Palosh, P.A.Sadovskiy",
        "5-Грицаенко И.А, Клименко С.В",
        "ЛаТЕХ га кириш"
    )



    val docNames = listOf(
        "LaTEXga kirish",
        "Sillabus",
        "Kalendar reja"
    )

    val presentationNames =
        (1 until 15)
            .map { "Taqdimot $it" }


}