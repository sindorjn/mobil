package com.example.latex.presentation.screens.quiz.components

sealed class QuizAction {
    data object Correct : QuizAction()
    data object InCorrect : QuizAction()
    data object NoAttemptsRemain : QuizAction()
    data object QuizCompleted : QuizAction()
    data object NavigateToModules : QuizAction()
    data class ShowErrorMessage(val message: String) : QuizAction()
}