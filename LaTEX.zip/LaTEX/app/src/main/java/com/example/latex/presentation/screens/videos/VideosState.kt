package com.example.latex.presentation.screens.videos

import com.example.latex.data.model.YouTubeVideo

data class VideosState(
    val videos: List<YouTubeVideo> = emptyList(),
    val query: String = "",
)