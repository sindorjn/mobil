package com.example.latex.presentation.components.custom_tab


import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun CustomTab(
    selectedItemIndex: Int,
    items: List<String>,
    modifier: Modifier = Modifier,
    onClick: (index: Int) -> Unit,
) {

    val density = LocalDensity.current
    var tabSize by remember {
        mutableStateOf(0.dp)
    }

    val indicatorOffset: Dp by animateDpAsState(
        targetValue = tabSize / items.size * selectedItemIndex,
        animationSpec = tween(easing = LinearOutSlowInEasing, durationMillis = 200), label = ""
    )

    Box(
        modifier = modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .height(intrinsicSize = IntrinsicSize.Min)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {

        Box(
            modifier = modifier
                .padding(horizontal = 4.dp)
                .fillMaxWidth()
                .height(intrinsicSize = IntrinsicSize.Min)
                .onGloballyPositioned { coordinates ->
                    tabSize = with(density) { coordinates.size.width.toDp() }
                }

        ) {
            MyTabBar(
                indicatorWidthFraction = 1F / items.size,
                indicatorOffset = indicatorOffset,
                indicatorColor = MaterialTheme.colorScheme.surfaceContainerLowest,
            )
            Row(
                horizontalArrangement = Arrangement.SpaceAround,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
            ) {
                items.mapIndexed { index, text ->
                    val isSelected = index == selectedItemIndex
                    MyTabItem(
                        isSelected = isSelected,
                        onClick = {
                            onClick(index)
                        },
                        tabWidth = tabSize / items.size,
                        text = text,
                    )
                }
            }
        }


    }
}