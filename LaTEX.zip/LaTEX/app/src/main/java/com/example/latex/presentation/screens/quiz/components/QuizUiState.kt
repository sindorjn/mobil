package com.example.latex.presentation.screens.quiz.components

import com.example.latex.presentation.model.QuestionData
import com.example.latex.presentation.model.QuizData


data class QuizUiState(
    val quizData: QuizData = QuizData(QuestionData.Text(""), emptyList(), 0),
    val selectedOption: Int? = null,
    val progress: Float? = null,
    val attempts: Int = Int.MAX_VALUE,
    val loading: Boolean = false,
)
