package com.example.latex.presentation.screens.theories

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.latex.data.TheoryRepository
import kotlinx.coroutines.launch

class TheoryViewModel(
    savedStateHandle: SavedStateHandle,
) : ViewModel() {


    private val repository: TheoryRepository = TheoryRepository
    var state by mutableStateOf(TheoryState())
        private set

    val lessonIndex = savedStateHandle.get<Int>("lessonIndex") ?: 0

    init {
        loadTheories()
    }

    private fun loadTheories() {
        viewModelScope.launch {
            state = state.copy(theories = repository.getTheories(lessonIndex))
        }
    }
}