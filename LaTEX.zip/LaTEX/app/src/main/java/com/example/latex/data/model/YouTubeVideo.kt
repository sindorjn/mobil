package com.example.latex.data.model

data class YouTubeVideo(
    val title: String,
    val thumbnailUrl: String,
    val videoUrl: String
)
