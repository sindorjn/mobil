package com.example.latex.presentation.screens.modules

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.latex.presentation.components.Module
import org.koin.androidx.compose.koinViewModel


@Composable

fun ModulesScreenRoot(
    viewModel: ModulesViewModule = koinViewModel(),
    onBack: () -> Unit,
    onModuleClick: (Int) -> Unit,
) {

    ModulesScreen(
        state = viewModel.state,
        onModuleClick =onModuleClick ,
        onBack =onBack
    )

}

@Composable
private fun ModulesScreen(
    state: ModulesState,
    onModuleClick: (Int) -> Unit,
    onBackClick: () -> Unit,
) {
    ModulesScreen(
        onBack = onBackClick,
        state = state,
        onModuleClick = { module -> onModuleClick(module) }
    )

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModulesScreen(
    onBack: () -> Unit,
    state: ModulesState,
    onModuleClick: (Int) -> Unit,
) {
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                modifier = Modifier,
                scrollBehavior = scrollBehavior,
                title = {
                    Spacer(Modifier.size(16.dp))
                    Text(
                        text = "Ma'ruzalar",
                        modifier = Modifier,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                },
                navigationIcon = {
                    Spacer(Modifier.size(16.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable {
                                onBack.invoke()
                            }
                            .padding(12.dp)
                    )
                }
            )
        },
        contentColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding)
        ) {
            items(state.modules.size) { index ->
                val name = state.modules[index]
                Module(
                    title = name,
                    moduleNumber = index + 1
                ) {
                    onModuleClick(index)
                }
            }
        }
    }
}