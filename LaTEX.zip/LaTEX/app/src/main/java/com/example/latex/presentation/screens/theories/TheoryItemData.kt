package com.example.latex.presentation.screens.theories

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

sealed class TheoryItemData {
    data class Title(@StringRes val titleRes: Int) : TheoryItemData()
    data class Description(@StringRes val descriptionRes: Int) : TheoryItemData()
    data class Image(@DrawableRes val imageRes: Int) : TheoryItemData()
}
