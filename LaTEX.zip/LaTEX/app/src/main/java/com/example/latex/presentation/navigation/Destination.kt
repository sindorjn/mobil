package com.example.latex.presentation.navigation

sealed class Destination(val route: String) {
    data object Home : Destination("home")
    data object Theory : Destination("theory")
    data object Video : Destination("video")
    data object Practice : Destination("practice")
    data object Quiz : Destination("quiz")
    data object Document : Destination("document")
    data object Modules : Destination("modules")
    data object Web : Destination("web")
}