package com.example.latex.presentation.screens.theories

data class TheoryState(
    val theories: List<TheoryItemData> = emptyList(),
)
