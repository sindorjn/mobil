package com.example.latex.presentation.model

sealed class QuestionData {
    data class Text(val text: String) : QuestionData()
    data class ImageAndText(val image: Int, val title: String) : QuestionData()
    data class TextAndImage(val title: String, val image: Int) : QuestionData()
}