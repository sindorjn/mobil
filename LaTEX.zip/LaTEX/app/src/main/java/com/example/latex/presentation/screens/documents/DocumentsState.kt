package com.example.latex.presentation.screens.documents

import com.example.latex.R

data class DocumentsState(
    val title: String = "",
    val itemNames: List<String> = emptyList(),
    val itemsTye: String = "document",
    val itemIcon: Int = R.drawable.doc,

)
