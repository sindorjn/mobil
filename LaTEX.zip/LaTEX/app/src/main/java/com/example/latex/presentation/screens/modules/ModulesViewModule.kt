package com.example.latex.presentation.screens.modules

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.latex.data.TheoryRepository

class ModulesViewModule : ViewModel() {

    var state by mutableStateOf(ModulesState())

    init {
        loadModules()
    }

    private fun loadModules() {
        state = state.copy(modules = TheoryRepository.getModuleNames())
    }


}