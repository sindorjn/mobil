package com.example.latex.presentation.navigation

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.latex.presentation.screens.documents.DocumentsScreenRoot
import com.example.latex.presentation.screens.home.HomeScreen
import com.example.latex.presentation.screens.modules.ModulesScreenRoot
import com.example.latex.presentation.screens.practice.PracticeScreenRoot
import com.example.latex.presentation.screens.quiz.QuizScreen
import com.example.latex.presentation.screens.theories.TheoryScreenRoot
import com.example.latex.presentation.screens.videos.VideosScreenRoot
import com.example.latex.presentation.screens.web.WebViewScreen


@RequiresApi(Build.VERSION_CODES.VANILLA_ICE_CREAM)
@Composable
fun SetupNavGraph(
    startDestination: String, navHostController: NavHostController,
) {
    NavHost(
        navController = navHostController,
        startDestination = startDestination
    ) {
        homeRoute(navHostController)
        videosRoute(navHostController)
        modulesRoute(navHostController)
        theoriesRoute(navHostController)
        quizRoute(navHostController)
        practiceRoute(navHostController)
        webRoute(navHostController)
        documentRoute(navHostController)
    }

}

fun NavGraphBuilder.homeRoute(
    navController: NavController,
) {
    composable(route = Destination.Home.route) {
        HomeScreen(
            onTheoriesClicked = {
                navController.navigate(Destination.Modules.route)
            },
            onVideosClicked = {
                navController.navigate(Destination.Video.route)
            },
            onPracticalClicked = {
                navController.navigate(Destination.Practice.route)
            },
            onQuizzesClicked = {
                navController.navigate(Destination.Quiz.route)
            },
            onDocumentsClicked = {
                navController.navigate(Destination.Document.route + "?itemType=document")
            },
            onPresentationsClicked = {
                navController.navigate(Destination.Document.route + "?itemType=presentation")
            },
            onGlossaryClicked = {
                navController.navigate(Destination.Web.route + "?urlIndex=0&practiceType=glossary")

            },
            onSourcesClicked = {
                navController.navigate(Destination.Document.route + "?itemType=source")
            }
        )
    }

}

fun NavGraphBuilder.videosRoute(
    navController: NavController,
) {
    composable(route = Destination.Video.route) {
        VideosScreenRoot(
            onBack = {
                navController.navigateUp()
            }
        )
    }

}

fun NavGraphBuilder.practiceRoute(
    navController: NavController,
) {
    composable(route = Destination.Practice.route) {
        PracticeScreenRoot(
            onBack = {
                navController.navigateUp()
            },
            onModuleClick = { type, ind ->
                navController.navigate(Destination.Web.route + "?urlIndex=$ind&practiceType=$type")
            }
        )
    }

}

fun NavGraphBuilder.documentRoute(
    navController: NavController,
) {
    composable(
        route = Destination.Document.route + "?itemType={itemType}",
        arguments = listOf(
            navArgument(name = "itemType") {
                type = NavType.StringType
                defaultValue = "document"
            }
        )
    ) {
        DocumentsScreenRoot(
            onBackClick = {
                navController.navigateUp()
            },
            onModuleClick = { type, ind ->
                navController.navigate(Destination.Web.route + "?urlIndex=$ind&practiceType=$type")
            },
        )
    }

}

@RequiresApi(Build.VERSION_CODES.VANILLA_ICE_CREAM)
fun NavGraphBuilder.quizRoute(
    navController: NavController,
) {
    composable(route = Destination.Quiz.route) {
        QuizScreen(
            onBack = {
                navController.navigateUp()
            },
            navigateToModules = {
                navController.navigateUp()
            },
        )
    }

}

fun NavGraphBuilder.modulesRoute(
    navController: NavController,
) {
    composable(route = Destination.Modules.route) {
        ModulesScreenRoot(
            onBack = {
                navController.navigateUp()
            },
            onModuleClick = { lessonIndex ->
                navController.navigate(Destination.Theory.route + "?lessonIndex=$lessonIndex")
            }
        )
    }

}


fun NavGraphBuilder.webRoute(
    navController: NavController,
) {
    composable(
        route = Destination.Web.route + "?urlIndex={urlIndex}&practiceType={practiceType}",
        arguments = listOf(
            navArgument(name = "urlIndex") {
                type = NavType.IntType
                defaultValue = 0
            },
            navArgument(name = "practiceType") {
                type = NavType.StringType
                defaultValue = "lab"
            }
        )
    ) {
        WebViewScreen(
            onBack = {
                navController.navigateUp()
            },
        )
    }

}

fun NavGraphBuilder.theoriesRoute(
    navController: NavController,
) {
    composable(
        route = Destination.Theory.route + "?lessonIndex={lessonIndex}",
        arguments = listOf(
            navArgument(name = "lessonIndex") {
                type = NavType.IntType
                defaultValue = 0
            }
        )
    ) {
        TheoryScreenRoot {
            navController.navigateUp()
        }
    }

}
