package com.example.latex.presentation.screens.practice

data class PracticeState(
    val courseName: String = "LaTex haqida",
    val modules: List<String> = emptyList(),
)
