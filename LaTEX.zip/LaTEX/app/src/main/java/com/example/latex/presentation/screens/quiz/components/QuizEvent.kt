package com.example.latex.presentation.screens.quiz.components

sealed class QuizEvent {
    data class SelectOption(val selectedOption: Int) : QuizEvent()
    data object Next : QuizEvent()
    data object UpdateProgress : QuizEvent()
}