package com.example.latex.presentation.screens.modules

data class ModulesState(
    val courseName: String = "LaTex haqida",
    val modules: List<String> = emptyList(),
)
