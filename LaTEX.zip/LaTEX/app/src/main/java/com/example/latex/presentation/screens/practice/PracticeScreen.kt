package com.example.latex.presentation.screens.practice

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.latex.R
import com.example.latex.presentation.components.Module
import com.example.latex.presentation.components.custom_tab.CustomTab
import kotlinx.coroutines.launch


@Composable

fun PracticeScreenRoot(
    onBack: () -> Unit,
    onModuleClick: (String, Int) -> Unit,
) {

    PracticeScreen(
        onModuleClick = onModuleClick,
        onBack = onBack
    )

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PracticeScreen(
    onBack: () -> Unit,
    onModuleClick: (String, Int) -> Unit,
) {
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior()


    val selected = remember { mutableIntStateOf(0) }
    val selectedTabItem by remember {
        derivedStateOf {
            selected
        }
    }

    val scope = rememberCoroutineScope()

    val pagerState = rememberPagerState(
        pageCount = { 2 },
        initialPage = selectedTabItem.intValue
    )


    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { page ->
            if (selectedTabItem.intValue != page) {
                selected.intValue = page
            }
        }
    }






    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                modifier = Modifier,
                scrollBehavior = scrollBehavior,
                title = {
                    Spacer(Modifier.size(16.dp))
                    Text(
                        text = "Topshiriqlar",
                        modifier = Modifier,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                },
                navigationIcon = {
                    Spacer(Modifier.size(16.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable {
                                onBack.invoke()
                            }
                            .padding(12.dp)
                    )
                }
            )
        },
        contentColor = MaterialTheme.colorScheme.background
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(padding),
            verticalArrangement = Arrangement.Top
        ) {
            CustomTab(
                items = listOf("Labaratorya", "Mustaqil ishi"),
                selectedItemIndex = selectedTabItem.intValue,
                onClick = {
                    scope.launch {
                        pagerState.animateScrollToPage(it)
                    }
                }
            )
            Spacer(modifier = Modifier.size(12.dp))

            HorizontalPager(
                state = pagerState,
                pageSize = PageSize.Fill,
                modifier = Modifier.weight(1F),
                verticalAlignment = Alignment.Top,
            ) { page ->
                if (page == 0) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()

                    ) {
                        items(9) { index ->
                            val name = "Labaratorya mashg'uloti"
                            Module(
                                title = name,
                                icon = R.drawable.lab,
                                moduleNumber = index + 1
                            ) {
                                onModuleClick("lab", index)
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()

                    ) {
                        items(4) { index ->
                            val name = "Mustaqil ishi"
                            Module(
                                title = name,
                                icon = R.drawable.sun,
                                moduleNumber = index + 1
                            ) {
                                onModuleClick("task", index)
                            }
                        }
                    }
                }

            }
        }


    }
}