package com.example.latex.presentation.screens.videos

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.latex.data.LocalRepository.sampleVideos
import kotlinx.coroutines.launch

class VideosViewModel : ViewModel() {

    var state by mutableStateOf(VideosState())
        private set

    init {
        viewModelScope.launch {
            state = state.copy(
                videos = sampleVideos
            )
        }
    }

    fun onAction(action: VideosAction) {
        viewModelScope.launch {
            when (action) {
                is VideosAction.OnSearch -> {
                    state = state.copy(
                        query = action.query,
                        videos = sampleVideos.filter {
                            it.title.contains(
                                action.query,
                                ignoreCase = true
                            )
                        }
                    )

                }

                else -> null
            }
        }
    }


}