package com.example.latex.presentation.screens.videos

sealed class VideosAction {
    data class OnSearch(val query: String) : VideosAction()
    data object OnBack : VideosAction()
}